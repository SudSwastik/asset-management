package com.sudarshan.sud.controller;


import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sudarshan.sud.dao.EmployeeRepository;
import com.sudarshan.sud.dao.StudentRepository;
import com.sudarshan.sud.entities.Employee;
import com.sudarshan.sud.entities.Student;
import com.sudarshan.sud.exception.RecordNotFoundException;

@Controller
@RequestMapping("/")
public class StudentController {

    private final StudentRepository studentRepository;
    
    @Autowired
	EmployeeRepository repository;
    
    
    @Autowired
    public StudentController(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }
    
    @RequestMapping
    public String getLoginPage() {
        
        return "redirect:/login";
    }
    
    @GetMapping("addasset")
    public String showSignUpForm(Student student, Errors error,  Employee employee, Model model) {

    	model.addAttribute("employee",repository.findAll());
    	if (error.hasErrors()) {
    		model.addAttribute("errorWhileSaving", true);
    		model.addAttribute("employee",repository.findAll());
            return "add-asset";
        }
    
        return "add-asset";
    }

    @GetMapping("viewassetlist")
    public String showUpdateForm(Model model) {
        model.addAttribute("students", studentRepository.findAll());
        return "index";
    }

    @PostMapping("addasset")
    public String addStudent(@Valid Student student, Errors error, BindingResult result, Model model) {
        
    	
    	if (error.hasErrors()) {
    		model.addAttribute("errorWhileSaving","true");
    		model.addAttribute("employee",repository.findAll());
            return "add-asset";
        }

        studentRepository.save(student);
        return "redirect:/home";
    }
    
    @GetMapping("updateasset/{id}")
    public String showUpdateForm(@PathVariable("id") long id, Model model) {
        Optional<Student> student = studentRepository.findById(id);
            if(student.isPresent()) {
            	model.addAttribute("student", student);
            	model.addAttribute("employee", repository.findAll());
            	return "update-asset";
            }
        
        return "update-asset";
    }

    @PostMapping("update")
    public String updateStudent( @Valid Student student, BindingResult result,
        Model model) {
        if (result.hasErrors()) {
//            student.setId(id);
            return "update-student";
        }

        studentRepository.save(student);
        model.addAttribute("students", studentRepository.findAll());
        return "redirect:/home";
    }



}
