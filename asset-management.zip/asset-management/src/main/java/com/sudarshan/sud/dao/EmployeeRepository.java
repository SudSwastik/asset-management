package com.sudarshan.sud.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import com.sudarshan.sud.entities.Employee;

@Service
public interface EmployeeRepository extends CrudRepository<Employee, Long> {

	@Override
	public List<Employee> findAll();
	
//	@Query("SELECT e.employeeId FROM Employee e")
//    public List<Employee> findByEmployeeId();
	
//	List<Employee> findByemployeeId(String employeeId);
}
