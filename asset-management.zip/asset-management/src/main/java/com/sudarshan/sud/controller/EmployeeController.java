package com.sudarshan.sud.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sudarshan.sud.dao.EmployeeRepository;
import com.sudarshan.sud.entities.Employee;

@Controller
@RequestMapping("/")
public class EmployeeController {

	@Autowired
	EmployeeRepository repository;
	
	@RequestMapping("/addemployee")
	public String displayProjectForm(Model model) {
		
		
		Employee employee = new Employee();
		model.addAttribute("employee",employee);
		return "new-employee";
	}
	
	@RequestMapping("/home")
	public String home() {
		
		return "home";
	}
	@RequestMapping("/save")
	public String createProject( @Valid Employee employee, Errors errors, Model model) {
		
		if (errors.hasErrors()) {
			model.addAttribute("invalidCredentials", true);
			return "new-employee";
		} else {
			repository.save(employee); 
			model.addAttribute("message", "Registration successfully...");
			return "redirect:/home";
		}
		
	}
	
}
