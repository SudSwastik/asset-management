package com.sudarshan.sud.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Entity
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public long id;

//    @NotBlank(message = "Name is mandatory")
//    @Column(name = "name")
//    public String name;
//
//    @NotBlank(message = "Email is mandatory")
//    @Column(name = "email")
//    public String email;
//
//    @Column(name = "phone_no")
//    public long phoneNo;
    
    @NotEmpty(message = "Asset Id is mandatory field")
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "Asset Id should be alpha numeric")
	private String assetId;

	@NotEmpty(message = "Product field is mandatory")
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "Product should be alpha numeric")
	private String productName;

	@NotEmpty(message = "Model field is mandatory")
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "Model should be alpha numeric")
	private String modelName;

	@NotEmpty(message = "Color field is mandatory")
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "Condition should be alphabets only")
	private String productColor;
	
	@NotEmpty(message = "Condition field is mandatory. ")
	@Pattern(regexp = "[a-zA-Z]*", message = "Condition should be alphabets only")
	private String productCondition;


	private String inUse;


	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Student(
//			@NotEmpty(message = "Asset Id is mandatory field") @Pattern(regexp = "[0-9]*", message = "Asset Id should be alpha numeric") 
			String assetId,
//			@NotEmpty(message = "Product field is mandatory") @Pattern(regexp = "[a-zA-Z]*", message = "Product should be alpha numeric")
			String productName,
//			@NotEmpty(message = "Model field is mandatory") @Pattern(regexp = "[a-zA-Z0-9]*", message = "Model should be alpha numeric") 
			String modelName,
//			@NotEmpty(message = "Color field is mandatory") String productColor,
//			@NotEmpty(message = "Condition field is mandatory. ") @Pattern(regexp = "[a-zA-Z]*", message = " Condition should be alphabets only") 
			String productCondition,
			String inUse, String employeeId, String productColor) {
		super();
		this.assetId = assetId;
		this.productName = productName;
		this.modelName = modelName;
		this.productColor = productColor;
		this.productCondition = productCondition;
		this.inUse = inUse;
		this.employeeId = employeeId;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getProductColor() {
		return productColor;
	}

	public void setProductColor(String productColor) {
		this.productColor = productColor;
	}

	public String getProductCondition() {
		return productCondition;
	}

	public void setProductCondition(String productCondition) {
		this.productCondition = productCondition;
	}

	public String getInUse() {
		return inUse;
	}

	public void setInUse(String inUse) {
		this.inUse = inUse;
	}

	private String employeeId;

	
    
    
    

    public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public Student() {}

    

    public void setId(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }

//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public void setEmail(String email) {
//        this.email = email;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public String getEmail() {
//        return email;
//    }
//
//    public long getPhoneNo() {
//        return phoneNo;
//    }
//
//    public void setPhoneNo(long phoneNo) {
//        this.phoneNo = phoneNo;
//    }
}