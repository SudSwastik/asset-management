package com.sudarshan.sud.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Entity
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public long id;
    
    @NotEmpty(message = "Asset Id is mandatory field")
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "Asset Id should be alpha numeric")
	public String assetId;

	@NotEmpty(message = "Product field is mandatory")
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "Product should be alpha numeric")
	public String productName;

	@NotEmpty(message = "Model field is mandatory")
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "Model should be alpha numeric")
	public String modelName;

	@NotEmpty(message = "Color field is mandatory")
	@Pattern(regexp = "[a-zA-Z0-9]*", message = "Condition should be alphabets only")
	public String productColor;
	
	@NotEmpty(message = "Condition field is mandatory. ")
	@Pattern(regexp = "[a-zA-Z]*", message = "Condition should be alphabets only")
	public String productCondition;


	public String inUse;


	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Student(
//			@NotEmpty(message = "Asset Id is mandatory field") @Pattern(regexp = "[0-9]*", message = "Asset Id should be alpha numeric") 
			String assetId,
//			@NotEmpty(message = "Product field is mandatory") @Pattern(regexp = "[a-zA-Z]*", message = "Product should be alpha numeric")
			String productName,
//			@NotEmpty(message = "Model field is mandatory") @Pattern(regexp = "[a-zA-Z0-9]*", message = "Model should be alpha numeric") 
			String modelName,
//			@NotEmpty(message = "Color field is mandatory") String productColor,
//			@NotEmpty(message = "Condition field is mandatory. ") @Pattern(regexp = "[a-zA-Z]*", message = " Condition should be alphabets only") 
			String productCondition,
			String inUse, String employeeId, String productColor) {
		super();
		this.assetId = assetId;
		this.productName = productName;
		this.modelName = modelName;
		this.productColor = productColor;
		this.productCondition = productCondition;
		this.inUse = inUse;
		this.employeeId = employeeId;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getProductColor() {
		return productColor;
	}

	public void setProductColor(String productColor) {
		this.productColor = productColor;
	}

	public String getProductCondition() {
		return productCondition;
	}

	public void setProductCondition(String productCondition) {
		this.productCondition = productCondition;
	}

	public String getInUse() {
		return inUse;
	}

	public void setInUse(String inUse) {
		this.inUse = inUse;
	}

	public String employeeId;


    public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public Student() {}

    

    public void setId(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }

	@Override
	public String toString() {
		return "Student [id=" + id + ", assetId=" + assetId + ", productName=" + productName + ", modelName="
				+ modelName + ", productColor=" + productColor + ", productCondition=" + productCondition + ", inUse="
				+ inUse + ", employeeId=" + employeeId + "]";
	}


}